#!/usr/bin/env python
"""Test the Bio.DocSQL module
"""

import Bio.DocSQL

print "Skipping Bio.DocSQL doctests."
#print "Running Bio.DocSQL doctests..."
#Bio.DocSQL._test()
#print "Bio.DocSQL doctests complete."
