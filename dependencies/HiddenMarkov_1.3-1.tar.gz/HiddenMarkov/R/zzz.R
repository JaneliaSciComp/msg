.First.lib <- function(lib, pkg) {
        library.dynam("HiddenMarkov", pkg, lib)
}
