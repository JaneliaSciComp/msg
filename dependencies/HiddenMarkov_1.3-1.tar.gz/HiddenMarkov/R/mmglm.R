mmglm <-
function (...)
{
    warning("Please change your function call 'mmglm' to 'mmglm0'. See the Manual page for further details.")
    x <- mmglm0(...)
    return(x)
}


