BaumWelch <- function (object, control, ...) 
    UseMethod("BaumWelch")

