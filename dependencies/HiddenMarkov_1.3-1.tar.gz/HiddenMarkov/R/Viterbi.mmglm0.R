Viterbi.mmglm0 <- function (object, ...)
    Viterbi(as.dthmm(object))
